package package1;

import java.sql.*;
import java.util.ArrayList;

public class BaseDatos {

    Connection conexion;
    Statement transaccion;
    ResultSet cursor;

    String cadenaConexion = "jdbc:mysql://beawjbj2yyqnjaghl7mq-mysql.services.clever-cloud.com:3306/beawjbj2yyqnjaghl7mq?zeroDateTimeBehavior=CONVERT_TO_NULL";
    String usuario = "u0cfrarvcxsasjio";
    String pass = "DwguZ7Y8WBkcaRIhtjMI";

    public BaseDatos() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection(cadenaConexion, usuario, pass);
            transaccion = conexion.createStatement();
        } catch (SQLException e) {
            System.out.println("no se conecto");
        } catch (ClassNotFoundException e) {
            System.out.println("no se conecto");
        }
    }

    public boolean insertar(Persona p) {
        String SQL_Insertar = "INSERT INTO `persona` (`id`, `nombre`, `domicilio`, `telefono`) VALUES (NULL, '%NOM%', '%DOM%', '%TEL%')";

        SQL_Insertar = SQL_Insertar.replace("%NOM%", p.nombre);
        SQL_Insertar = SQL_Insertar.replace("%DOM%", p.domicilio);
        SQL_Insertar = SQL_Insertar.replace("%TEL%", p.telefono);
        try {
            transaccion.execute(SQL_Insertar);
        } catch (SQLException e) {
            return false;
        }
        return true;
    }

    public ArrayList<String[]> mostrarTodos() {
        ArrayList<String[]> personas = new ArrayList<String[]>();

        try {
            cursor = transaccion.executeQuery("SELECT * FROM `persona`");
            if (cursor.next()) {
                do {

                    String[] temporal = {"" + cursor.getInt("id"),
                        cursor.getString("nombre"),
                        cursor.getString("domicilio"),
                        cursor.getString("telefono")};

                    personas.add(temporal);

                } while (cursor.next());
            }
        } catch (Exception e) {
            return null;
        }
        return personas;
    }

    public Persona obtenerPorID(String IDaBuscar) {
        String SQL_Consulta = "SELECT * FROM `persona` WHERE `ID` =" + IDaBuscar;
        try {
            cursor = transaccion.executeQuery(SQL_Consulta);
            if (cursor.next()) {
                Persona p = new Persona(
                        cursor.getInt(1),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getString(4)
                );
                return p;
            }

        } catch (Exception e) {
        }
        return new Persona(-1, "", "", "");
    }

    public boolean eliminar(String idPersona) {
        try {
            String SQL = ("DELETE FROM `persona` WHERE `persona`.`id` =" + idPersona);
            transaccion.execute(SQL);
        } catch (SQLException e) {
            return false;
        }
        return true;
    }

    public boolean actualizar(Persona p) {
        try {
            String SQL = "UPDATE `persona` SET `nombre` = 'c1', `domicilio` = 'c2', `telefono` = 'c3' WHERE `persona`.`id` =" + p.id+";";

            SQL = SQL.replace("c1", p.nombre);
            SQL = SQL.replace("c2", p.domicilio);
            SQL = SQL.replace("c3", p.telefono);

            transaccion.execute(SQL);
        } catch (SQLException e) {
            return false;
        }
        return true;
    }
}
